/*
   New Perspectives on HTML5, CSS, and JavaScript
   Tutorial 14
   Tutorial Case

   Author: 
   Date:   

   Filename: switchStyle.js


   Functions List:


   changeStyle(sheet)
      Changes style sheet from the currently active sheet to whatever style sheet
      is clicked by the user from the specified style sheet title indicated by
      the sheet parameter

*/


