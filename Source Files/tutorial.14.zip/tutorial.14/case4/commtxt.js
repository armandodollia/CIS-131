/*
   New Perspectives on HTML5, CSS, and JavaScript
   Tutorial 14
   Case Problem 4

   Author: 
   Date:   

   Filename: comments.js


*/

